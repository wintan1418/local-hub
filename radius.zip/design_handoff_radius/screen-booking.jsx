// Booking flow

function BookingScreen({ onNavigate }) {
  const [step, setStep] = React.useState(1);
  const [selectedDate, setSelectedDate] = React.useState(15);
  const [selectedTime, setSelectedTime] = React.useState("10:00");

  const days = ["S", "M", "T", "W", "T", "F", "S"];
  // Generate calendar days for April 2026
  const calDays = [];
  for (let i = 0; i < 3; i++) calDays.push({ d: 30 + i - 2, muted: true });
  for (let i = 1; i <= 30; i++) {
    const unavail = [2, 5, 9, 13, 19, 22, 26].includes(i);
    calDays.push({ d: i, muted: false, unavail, today: i === 28 });
  }

  const times = ["8:00", "9:00", "10:00", "11:00", "12:00", "1:00", "2:00", "3:00", "4:00", "5:00", "6:00", "7:00"];
  const unavailTimes = ["8:00", "1:00", "5:00"];

  return (
    <main data-screen-label="Booking Flow">
      <div className="container booking-page">
        <button className="btn btn-ghost btn-sm" style={{ paddingLeft: 0, marginBottom: 16 }} onClick={() => onNavigate("profile")}>
          <Icon name="arrowLeft" size={14}/> Back to Maya's profile
        </button>

        <h1 className="display" style={{ fontSize: 44, marginBottom: 24 }}>Confirm your booking</h1>

        <div className="booking-stepper">
          {["Schedule", "Details", "Payment"].map((s, i) => {
            const n = i + 1;
            const cls = n === step ? "active" : n < step ? "done" : "";
            return (
              <div key={s} className={`booking-step ${cls}`}>
                <span className="booking-step-num">{n < step ? <Icon name="check" size={12}/> : n}</span>
                <span>{s}</span>
              </div>
            );
          })}
        </div>

        <div className="booking-grid">
          <div>
            {step === 1 && (
              <>
                <div className="calendar">
                  <div className="cal-head">
                    <span className="cal-month">April 2026</span>
                    <div style={{ display: "flex", gap: 4 }}>
                      <IconButton icon="arrowLeft"/>
                      <IconButton icon="arrow"/>
                    </div>
                  </div>
                  <div className="cal-grid">
                    {days.map((d, i) => <div className="cal-day-name" key={i}>{d}</div>)}
                    {calDays.map((c, i) => (
                      <button
                        key={i}
                        className={`cal-day ${c.muted ? "muted" : ""} ${c.unavail ? "unavail" : ""} ${c.today ? "today" : ""} ${selectedDate === c.d && !c.muted ? "selected" : ""}`}
                        disabled={c.unavail || c.muted}
                        onClick={() => setSelectedDate(c.d)}
                      >
                        {c.d}
                      </button>
                    ))}
                  </div>
                </div>

                <h3 style={{ fontFamily: "var(--font-display)", fontSize: 22, marginBottom: 16 }}>Available times — Apr {selectedDate}</h3>
                <div className="timeslots">
                  {times.map(t => (
                    <button
                      key={t}
                      className={`timeslot ${unavailTimes.includes(t) ? "unavail" : ""} ${selectedTime === t ? "selected" : ""}`}
                      disabled={unavailTimes.includes(t)}
                      onClick={() => setSelectedTime(t)}
                    >
                      {t}
                    </button>
                  ))}
                </div>

                <div style={{ display: "flex", justifyContent: "space-between", marginTop: 32 }}>
                  <button className="btn btn-ghost" onClick={() => onNavigate("profile")}>Cancel</button>
                  <button className="btn btn-primary btn-lg" onClick={() => setStep(2)}>Continue to details</button>
                </div>
              </>
            )}

            {step === 2 && (
              <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                <div>
                  <label className="label">Service type</label>
                  <select className="select">
                    <option>Deep clean — full apartment</option>
                    <option>Standard recurring clean</option>
                    <option>Move-out turnover</option>
                  </select>
                </div>
                <div>
                  <label className="label">Property size</label>
                  <select className="select">
                    <option>1 bedroom · ~750 sq ft</option>
                    <option>Studio · ~500 sq ft</option>
                    <option>2 bedroom · ~1100 sq ft</option>
                  </select>
                </div>
                <div>
                  <label className="label">Address</label>
                  <input className="input" defaultValue="247 Lafayette Ave, Brooklyn, NY 11238"/>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <div>
                    <label className="label">Apt / Unit</label>
                    <input className="input" placeholder="e.g. 4B"/>
                  </div>
                  <div>
                    <label className="label">Access notes</label>
                    <input className="input" placeholder="Doorman, code, etc."/>
                  </div>
                </div>
                <div>
                  <label className="label">Special instructions</label>
                  <textarea className="textarea" rows="4" placeholder="Allergies, pets, focus areas, things to avoid…"></textarea>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12 }}>
                  <button className="btn btn-ghost" onClick={() => setStep(1)}><Icon name="arrowLeft" size={14}/> Back</button>
                  <button className="btn btn-primary btn-lg" onClick={() => setStep(3)}>Continue to payment</button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                <div className="card" style={{ padding: 20 }}>
                  <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                    <div style={{ width: 40, height: 28, background: "var(--ink)", borderRadius: 4 }}></div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600 }}>Visa ending 4242</div>
                      <div style={{ fontSize: 12, color: "var(--ink-3)" }}>Expires 04/28</div>
                    </div>
                    <button className="btn btn-ghost btn-sm">Change</button>
                  </div>
                </div>

                <div className="card" style={{ padding: 20, background: "var(--accent-soft)", borderColor: "transparent" }}>
                  <div style={{ display: "flex", gap: 12 }}>
                    <Icon name="shield" size={20}/>
                    <div>
                      <div style={{ fontWeight: 600, marginBottom: 4 }}>Protected by Radius Guarantee</div>
                      <div style={{ fontSize: 13, color: "var(--ink-2)" }}>Your payment is held until the job is complete and you've confirmed everything looks great. Free cancellation up to 24h before.</div>
                    </div>
                  </div>
                </div>

                <label className="filter-checkbox" style={{ padding: 0 }}>
                  <input type="checkbox" defaultChecked/>
                  <span>I agree to the Terms of Service and acknowledge the cancellation policy.</span>
                </label>

                <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12 }}>
                  <button className="btn btn-ghost" onClick={() => setStep(2)}><Icon name="arrowLeft" size={14}/> Back</button>
                  <button className="btn btn-accent btn-lg" onClick={() => onNavigate("dashboard")}>Confirm & pay $144</button>
                </div>
              </div>
            )}
          </div>

          <aside>
            <div className="summary-card">
              <div className="summary-prov">
                <Avatar name="Maya O." size={48}/>
                <div>
                  <div style={{ fontWeight: 600 }}>Maya Okonkwo</div>
                  <div style={{ fontSize: 13, color: "var(--ink-3)" }}>Cleaning · 4.96 ★</div>
                </div>
              </div>

              <div className="summary-line"><span>Date</span><span>Apr {selectedDate}, 2026</span></div>
              <div className="summary-line"><span>Time</span><span>{selectedTime} AM</span></div>
              <div className="summary-line"><span>Service</span><span>Deep clean · 1BR</span></div>
              <div className="summary-line"><span>Duration</span><span>~3 hrs</span></div>

              <div style={{ borderTop: "1px solid var(--line)", marginTop: 12, paddingTop: 12 }}>
                <div className="summary-line"><span>Service ($48 × 3)</span><span>$144.00</span></div>
                <div className="summary-line"><span>Service fee</span><span>$8.40</span></div>
                <div className="summary-line"><span>Tax</span><span>$13.50</span></div>
                <div className="summary-line total"><span>Total</span><span>$165.90</span></div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}

window.BookingScreen = BookingScreen;
