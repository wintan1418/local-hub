# Handoff: Radius — Service Marketplace Redesign

## Overview

Radius is a two-sided service marketplace connecting clients with vetted local
service providers (cleaning, handywork, beauty/wellness, tutoring, pet care,
personal training, event services, tech help). This handoff package contains a
complete redesign of the public + provider-dashboard surface, replacing the
prior generic SaaS look with a warm editorial direction.

## About the Design Files

The files in this bundle are **design references created in HTML** —
interactive React prototypes showing intended look, layout, and behavior.
**They are not production code to copy directly.** The task is to recreate
these designs in the target codebase's existing environment using its
established patterns and libraries — or, if no environment exists yet, to
choose the most appropriate framework (Next.js + Tailwind is a good default for
this kind of marketplace) and implement there.

The prototypes are split into:
- `Radius Redesign.html` — entrypoint, mounts `<App/>`, holds the screen router
  and the Tweaks panel
- `styles.css` — design tokens (CSS custom props), base reset, shared utilities
- `app.css` — component + screen-specific styles
- `components.jsx` — shared UI primitives (Icon, Avatar, Stars, TopNav, cards…)
- `data.jsx` — mock data (categories, providers, reviews, bookings, messages)
- `screen-home.jsx` — landing / discover
- `screen-search.jsx` — filter + list + map
- `screen-profile.jsx` — provider profile
- `screen-booking.jsx` — 3-step booking flow
- `screen-dashboard.jsx` — provider dashboard
- `tweaks-panel.jsx` — in-prototype theme switcher (do not port)

## Fidelity

**High-fidelity.** Final colors, typography, spacing, layout, and interactions
are all settled. All photography is rendered as labeled striped placeholders
(`.img-ph` class) — the implementer should swap real photography in at the
points indicated by the placeholder labels (e.g. `provider-at-work.jpg · 4:5`,
`maya-1.jpg · main`).

The prototype ships with three themes via a Tweaks panel:
- **warm** (default, `data-theme` unset) — warm editorial direction
- **bold** (`data-theme="bold"`) — dark + lime modern
- **mono** (`data-theme="mono"`) — minimal black/white

The default Warm direction is the canonical one. Mono and Bold are presented
as alternates to discuss with the team.

## Design Tokens

All tokens live as CSS custom properties in `styles.css`. Reproduce them in
your token system (Tailwind theme, design-tokens JSON, CSS vars, etc.).

### Colors — Warm theme (default)

| Token | Value | Use |
|---|---|---|
| `--bg` | `#f7f4ee` | Page background (warm off-white) |
| `--bg-elevated` | `#ffffff` | Cards, panels, search bar |
| `--bg-sunken` | `#efeae0` | Filter sidebar, sunken sections |
| `--ink` | `#1a1a17` | Primary text, primary buttons |
| `--ink-2` | `#3d3a33` | Secondary text |
| `--ink-3` | `#6f6a5e` | Tertiary text, captions |
| `--ink-4` | `#a09a8a` | Disabled, dividers in text |
| `--line` | `#e3ddd0` | Borders, dividers |
| `--line-strong` | `#c9c2b1` | Input borders, stronger dividers |
| `--accent` | `#1f4d3a` | Brand mark, primary accent (deep forest) |
| `--accent-2` | `#d96a3a` | Emphasis, badges (terracotta) |
| `--accent-soft` | `#e8efe8` | Tag bg, guarantee callout bg |
| `--warn` | `#b8551c` | Pending status |
| `--good` | `#2d6e4e` | Confirmed status, positive trend |

### Colors — Bold theme

| Token | Value |
|---|---|
| `--bg` | `#0e0e10` |
| `--bg-elevated` | `#18181c` |
| `--bg-sunken` | `#08080a` |
| `--ink` | `#f5f5f0` |
| `--accent` | `#c4ff4a` (lime) |
| `--accent-2` | `#ff6b3d` |

### Colors — Mono theme

Pure black/white with grey scale. `--accent` = `--ink` = `#0a0a0a`.

### Typography

| Token | Value | Use |
|---|---|---|
| `--font-display` | `"Fraunces", serif` | All h1/h2/h3 in marketing surfaces, KPIs, prices, calendar month |
| `--font-ui` | `"Inter", sans-serif` | Body, controls, nav, all running UI text |
| `--font-mono` | `"JetBrains Mono", monospace` | Eyebrows, counts, dates in dashboard tables, version chip |

**Display style detail:** Fraunces is used at variation `SOFT 30, WONK 0` for
regular display, and `SOFT 100, WONK 1` italic for the emphasised single
italicised word in headers (e.g. *"actually"*, *"well"*, *"Done"*) — render in
`var(--accent)` color. This typographic accent is a signature of the design
and must be preserved.

**Type scale (clamp-based responsive):**
- Hero `h1`: `clamp(48px, 8vw, 104px)`, line-height 0.95, letter-spacing -0.035em
- Section title: 32px / 1.05 / -0.02em
- Profile name: `clamp(36px, 5vw, 56px)` / 1 / -0.02em
- Card headline (list): 22px / 1.1 / -0.01em
- Card headline (grid): 17px
- Body: 15px / 1.5 (Inter)
- Hero sub: 19px / 1.5
- Eyebrow: 11px mono uppercase, letter-spacing 0.12em

### Spacing scale

`--s-1`..`--s-9`: 4, 8, 12, 16, 24, 32, 48, 64, 96 px

### Radii

`--r-1` 4px · `--r-2` 8px · `--r-3` 12px · `--r-4` 20px · `--r-pill` 999px

Buttons + search bar use pill. Cards use `--r-3`. CTA banner + gallery use `--r-4`.

### Shadows

| Token | Value |
|---|---|
| `--shadow-sm` | `0 1px 2px rgba(26,26,23,0.04), 0 1px 1px rgba(26,26,23,0.03)` |
| `--shadow-md` | `0 4px 16px rgba(26,26,23,0.06), 0 1px 2px rgba(26,26,23,0.04)` |
| `--shadow-lg` | `0 12px 40px rgba(26,26,23,0.08), 0 2px 6px rgba(26,26,23,0.04)` |

## Screens / Views

There are 5 screens. Top nav is persistent (sticky, blurred, 1280px max-width).

### 1. Home / Discover (`screen-home.jsx`)

**Purpose:** Landing for both seekers and providers. Drive search + category browse.

**Sections, top to bottom:**

1. **Hero** — 60/40 grid (text / image). Eyebrow → display headline with
   italic-wonk emphasis word (`em` styled `font-style: italic;
   font-variation-settings: 'SOFT' 100, 'WONK' 1; color: var(--accent)`) →
   description → pill search bar (What / Where / circular submit) → trust
   strip (3 items: shield, bolt, check icons + label, separated by top
   border).
   - Hero image: 4:5 placeholder with two floating tag chips (provider avatar
     + name + rating; status dot + booking confirmation). The chips break
     out of the image bounds (top-left negative `left: -20px`, bottom-right
     negative `right: -30px`).

2. **Categories** — 4-column grid (`repeat(4, 1fr)`, gap 12px). Each card:
   160px min-height, vertical flex layout, swatch (36px circle, category
   color) at top, display heading at middle, mono count at bottom. Hover
   raises -2px with shadow-md. Mobile: 2-col.

3. **Featured providers (sunken)** — full-bleed band with `bg-sunken`. 4-col
   provider grid card (`ProviderCardGrid`).

4. **How it works** — 3-col grid bordered top + bottom by `--line`, internal
   1px dividers. Each step: italic display number in accent color (56px),
   display title (24px), body (14px / 1.55).

5. **Recently active** — repeats grid card layout for the remaining 4
   providers.

6. **CTA banner** — `bg: var(--ink)` block, white text, 1.5fr/1fr grid.
   Display headline with italic emphasis word in `var(--accent-2)`. Two
   buttons: solid (inverted to `--bg`) + ghost.

7. **Footer** — 4-col grid (brand col 2x wide), top border, link columns,
   bottom row with copyright + version chip in mono.

### 2. Search Results (`screen-search.jsx`)

**Purpose:** Filter and discover providers.

**Layout:** Three columns, full viewport height minus top nav.
- `280px` filter sidebar (border-right) — categories (with checkbox + count),
  price range (min/max inputs), rating tiers, verification, availability,
  Clear button.
- `1fr` results column — sticky-ish search head (count + sort select + view
  toggle list/grid), then `ProviderCardList` (default) or `ProviderCardGrid`
  layout.
- `1fr` map column — decorative background gradients + 1px grid, 4 curved
  road paths (SVG), and pill-shaped price pins (`$48`, `$75`…) positioned
  absolutely. Hovered/active pin inverts to `--ink` background.

Below 1100px: drop the map. Below 768px: drop the filters too (collapse
behind a button in production).

### 3. Provider Profile (`screen-profile.jsx`)

**Purpose:** Convince + book a single provider.

- Back link (ghost button) at top.
- **Gallery** — 3-col / 2-row grid (480px tall), first cell spans both rows.
  Mobile: collapse to single image, 280px tall.
- **Two-column layout below**: 1fr main / 380px sticky sidebar.
- **Main column sections** (each with top `1px solid --line` divider):
  - Head: eyebrow (category) → 56px name → 18px subtitle → stats row (rating,
    location, response time, jobs completed)
  - About: bio paragraph + accent badge tags
  - What I offer: 2-col skill list with check icons in accent color
  - Reviews: large rating number + per-star bar chart, then individual review
    cards with avatar/author/date/body/job-tag
- **Sidebar (sticky, top: 80px)**: rate (40px display) + rating, two
  side-by-side info fields (Date/Time and Service), accent CTA "Request to
  book", note "You won't be charged yet", estimated total, secondary
  "Message {firstName}" button.

### 4. Booking Flow (`screen-booking.jsx`)

**Purpose:** Convert intent to a confirmed booking.

3-step stepper across the top (Schedule → Details → Payment). Active step
gets `--ink` border-bottom + dark numbered chip; completed step shows
checkmark in accent. Two-column layout: 1fr form / 380px sticky summary.

- **Step 1:** Calendar (current month, weekday header, days; muted/unavail/
  today/selected states), then 4-col timeslots grid (8am–7pm, some unavail).
- **Step 2:** Service type select, property size select, address input, two
  side-by-side (apt / access notes), special instructions textarea.
- **Step 3:** Saved card row in a card, accent-soft "Radius Guarantee"
  callout with shield icon, ToS checkbox, Confirm & pay CTA.

**Summary card:** provider chip (avatar + name + rating) → schedule lines →
fee breakdown → total in display font, 22px.

### 5. Provider Dashboard (`screen-dashboard.jsx`)

**Purpose:** Operational home for providers.

- **Sidebar (220px, sunken bg):** title (provider name), 7 nav items
  (Overview, Bookings, Messages with unread badge, Earnings, Reviews,
  Profile, Settings). Active item gets `--bg` background + shadow-sm.
  Bottom: profile-health card with progress bar.
- **Main:** greeting head (display 44px) + sub. Action buttons (Block time,
  Add service).
- **KPI grid:** 4 cards (Earnings $740, Bookings 17, Rating 4.96, Response
  12m) with label, large display number, trend chip (▲/▼ + delta), and
  6-point sparkline SVG.
- **2-col panel grid (1.5fr / 1fr):**
  - Upcoming bookings list — 4-col row (date chip, client/service, status
    pill, amount).
  - Messages — avatar, from (with unread dot), preview, mono time.
- **Earnings chart panel** — 12-month area + line chart with grid lines and
  point markers. Header shows total + YoY trend.

## Interactions & Behavior

- **Navigation** — In the prototype it's React state-based (`screen` var). In
  production: standard route per screen.
- **Top-nav** — sticky, `backdrop-filter: blur(10px)`, semi-transparent bg
  via `color-mix`.
- **Cards** — list cards translate -1px and gain `--shadow-md` + stronger
  border on hover; grid cards translate -2px on hover.
- **Buttons** — all buttons get a `transform: translateY(1px)` on `:active`.
  Three variants: primary (ink/bg), accent (var(--accent)/white), secondary
  (elevated/line).
- **Search bar fields** — clicking the field area focuses the input;
  hovering adds `--bg-sunken` background.
- **Map pins** — hovering inverts color (active state).
- **Calendar** — selected day gets ink fill; unavailable days are muted +
  strikethrough + disabled.
- **Stepper** — `step` state drives active/done class; advancing through
  steps is the primary forward motion of the booking screen.
- **Tweaks panel** — prototype only; do not port.

## State Management

Per-screen client state is minimal:
- Home: `searchQ`, `searchLoc` (controlled inputs)
- Search: `view` (`list`/`grid`), `activePin` (provider id), `selectedCats`
- Profile: read-only by `providerId`
- Booking: `step` (1–3), `selectedDate` (day-of-month int), `selectedTime`
- Dashboard: `section` (active nav id)

Production data needs:
- Categories (id, label, icon-or-color, count)
- Providers (id, name, title, category, rating, reviews count, rate +
  rateUnit, location, distance from user, badges[], response time, completed
  count, years active, bio, gallery images)
- Reviews (per provider, with author/rating/date/body/job)
- Bookings (per provider/user, with client, service, date/time, status,
  amount, timeline)
- Messages (per provider, threaded)
- Earnings rollups (per week / month / 12 months)
- Provider profile-health (computed % + missing fields list)

## Components Inventory

Top-level reusable components in `components.jsx`:

- `<Icon name size stroke>` — line icons (search, pin, star, arrow, check,
  chat, calendar, shield, bolt, heart, sliders, grid, list, bell, plus, x,
  menu, clock, dollar, home, user, chart, inbox, settings, arrowLeft)
- `<Avatar name size src>` — initials avatar with deterministic OKLCH hue
  per name
- `<ImgPlaceholder label ratio>` — striped placeholder with mono caption
  chip; **replace at integration time**
- `<Stars rating size showNum count>` — single filled star + numeric rating
  + parenthesized count
- `<TopNav current onNavigate>` — main nav
- `<ProviderCardList provider onClick>` — horizontal card (image + body +
  rate)
- `<ProviderCardGrid provider onClick>` — vertical card with overlay badge
  + favorite

Implement as proper components in your framework with prop types matching the
above.

## Responsive Behavior

Breakpoints used: 1100px (drop map column on Search), 900px (collapse most
2-col layouts to 1, drop dashboard sidebar), 768px (mobile — drop secondary
nav links, drop filter sidebar, collapse footer to 2-col).

## Assets

- **Fonts** — Google Fonts: Fraunces (variable, with SOFT + WONK axes),
  Inter, JetBrains Mono. Already imported in `Radius Redesign.html`.
- **Imagery** — None included. All instances are striped CSS placeholders.
  Implementer must source or commission photography for: hero, provider
  profile galleries (5 per provider minimum), category card backgrounds (if
  going beyond swatch treatment).
- **Icons** — All inline SVG, see `Icon` component. Replace with your icon
  library (Lucide is the closest match in style and naming).
- **Brand mark** — Pure CSS: `.brand-mark` is a 28px circle in
  `var(--accent)` with a 1.5px ring inset 6px. No raster logo file is
  needed; the wordmark is set in Fraunces 22/500 lowercase.

## Files

```
design_handoff_radius/
├── README.md                  ← this file
├── Radius Redesign.html       ← entrypoint, screen router, Tweaks panel
├── styles.css                 ← tokens + base + utilities
├── app.css                    ← component + screen styles
├── data.jsx                   ← mock data
├── components.jsx             ← shared primitives
├── screen-home.jsx
├── screen-search.jsx
├── screen-profile.jsx
├── screen-booking.jsx
├── screen-dashboard.jsx
└── tweaks-panel.jsx           ← prototype-only, do not port
```

## Implementation Notes for Claude Code

- The current site is a Rails-flavored HatchBox app. You can keep Rails on
  the server side and ship the redesigned UI as either ERB partials with the
  CSS as-is, or migrate the marketing/marketplace surface to a Next.js +
  Tailwind frontend that talks to a Rails JSON API. Either is reasonable;
  pick based on team comfort.
- `var(--*)` token names map cleanly onto Tailwind's `theme.extend.colors`
  and CSS-variable workflow. If using Tailwind, define each token under a
  semantic key (`bg`, `ink`, `accent`, …) rather than reusing utility names.
- Preserve the **Fraunces italic-wonk emphasis word** in headlines — it is a
  load-bearing piece of the brand voice.
- Do **not** introduce gradients, glassmorphism, or rounded-corner left-
  border accent containers. The design intentionally avoids these.
- Provider cards must always show: photo, name (display font), rating + count,
  one-line title, location/distance, rate + unit. Top-Rated badge overlays
  the photo at top-left when present.
- The Mono and Bold themes share structure — do not redesign per theme; they
  are pure token swaps.
