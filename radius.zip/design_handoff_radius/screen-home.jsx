// Home / Discover screen

function HomeScreen({ onNavigate, onProvider }) {
  const { CATEGORIES, PROVIDERS } = window.RADIUS_DATA;
  const [searchQ, setSearchQ] = React.useState("");
  const [searchLoc, setSearchLoc] = React.useState("Brooklyn, NY");

  return (
    <main data-screen-label="Home / Discover">
      {/* Hero */}
      <section className="hero">
        <div className="container">
          <div className="hero-grid">
            <div>
              <div className="eyebrow hero-eyebrow">◐ Local services · vetted providers · transparent pricing</div>
              <h1 className="hero-title">
                Find someone who <em>actually</em> shows up.
              </h1>
              <p className="hero-sub">
                Radius connects you with background-checked local pros for cleaning, repairs,
                tutoring, and more. Real reviews. Real rates. No bidding wars.
              </p>

              <div className="searchbar">
                <div className="searchbar-field">
                  <span className="searchbar-field-label">What</span>
                  <input
                    placeholder="Cleaning, plumber, dog walker…"
                    value={searchQ}
                    onChange={(e) => setSearchQ(e.target.value)}
                  />
                </div>
                <div className="searchbar-divider"></div>
                <div className="searchbar-field" style={{ maxWidth: 200 }}>
                  <span className="searchbar-field-label">Where</span>
                  <input
                    placeholder="ZIP or neighborhood"
                    value={searchLoc}
                    onChange={(e) => setSearchLoc(e.target.value)}
                  />
                </div>
                <button className="searchbar-go" onClick={() => onNavigate("search")} aria-label="Search">
                  <Icon name="search" size={18} stroke={2}/>
                </button>
              </div>

              <div className="trust-strip">
                <span className="trust-item"><Icon name="shield" size={16}/> Background checked</span>
                <span className="trust-item"><Icon name="bolt" size={16}/> ~14 min avg response</span>
                <span className="trust-item"><Icon name="check" size={16}/> 4.9 average rating</span>
              </div>
            </div>

            <div className="hero-visual">
              <ImgPlaceholder label="provider-at-work.jpg · 4:5" ratio="4/5" style={{ height: "100%" }}/>
              <div className="hero-visual-tag" style={{ top: 20, left: -20 }}>
                <Avatar name="Maya O." size={32}/>
                <div>
                  <div style={{ fontWeight: 600 }}>Maya O.</div>
                  <div style={{ fontSize: 11, color: "var(--ink-3)" }}>Cleaning · 4.96 ★</div>
                </div>
              </div>
              <div className="hero-visual-tag" style={{ bottom: 30, right: -30 }}>
                <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--good)" }}></span>
                <div>
                  <div style={{ fontWeight: 600 }}>Booked in 3 minutes</div>
                  <div style={{ fontSize: 11, color: "var(--ink-3)" }}>Tomorrow, 10:00 AM</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section style={{ padding: "60px 0" }}>
        <div className="container">
          <div className="section-head">
            <div>
              <div className="eyebrow" style={{ marginBottom: 10 }}>◑ Browse by category</div>
              <h2 className="section-title">Eight things we do <em style={{ fontStyle: "italic", fontVariationSettings: "'SOFT' 100, 'WONK' 1", color: "var(--accent)" }}>well</em>.</h2>
            </div>
            <button className="btn btn-ghost" onClick={() => onNavigate("search")}>
              All categories <Icon name="arrow" size={14}/>
            </button>
          </div>

          <div className="categories-grid">
            {CATEGORIES.map((c) => (
              <button key={c.id} className="category-card" onClick={() => onNavigate("search")}>
                <span className="category-swatch" style={{ background: c.swatch }}>{c.icon}</span>
                <div>
                  <h3 className="category-name">{c.label}</h3>
                </div>
                <span className="category-count">{c.count.toLocaleString()} pros nearby</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured providers */}
      <section style={{ padding: "60px 0", background: "var(--bg-sunken)" }}>
        <div className="container">
          <div className="section-head">
            <div>
              <div className="eyebrow" style={{ marginBottom: 10 }}>◒ Featured this week</div>
              <h2 className="section-title">Top-rated pros near you.</h2>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn btn-secondary btn-sm">Filter</button>
              <button className="btn btn-secondary btn-sm" onClick={() => onNavigate("search")}>View all</button>
            </div>
          </div>

          <div className="providers-grid">
            {PROVIDERS.slice(0, 4).map((p) => (
              <ProviderCardGrid key={p.id} provider={p} onClick={onProvider}/>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section style={{ padding: "80px 0" }}>
        <div className="container">
          <div className="section-head" style={{ marginBottom: 40 }}>
            <div>
              <div className="eyebrow" style={{ marginBottom: 10 }}>◓ How it works</div>
              <h2 className="section-title">Three steps. <em style={{ fontStyle: "italic", fontVariationSettings: "'SOFT' 100, 'WONK' 1", color: "var(--accent)" }}>Done</em>.</h2>
            </div>
          </div>

          <div className="how-grid">
            {[
              { n: "01", t: "Search & compare", b: "Tell us what you need. We'll surface vetted pros nearby with rates, reviews, and real availability — no bidding wars or robo-quotes." },
              { n: "02", t: "Book & pay securely", b: "Pick a slot, confirm details, and pay through Radius. Your money is held until the job's done — and you're happy with it." },
              { n: "03", t: "Get it done & review", b: "Track progress, message your pro, and leave a review. We handle scheduling, receipts, and disputes if anything goes sideways." },
            ].map((s) => (
              <div className="how-step" key={s.n}>
                <div className="how-num">{s.n}</div>
                <h3 className="how-title">{s.t}</h3>
                <p className="how-body">{s.b}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* More providers */}
      <section style={{ padding: "60px 0 80px" }}>
        <div className="container">
          <div className="section-head">
            <div>
              <div className="eyebrow" style={{ marginBottom: 10 }}>◔ Browse more</div>
              <h2 className="section-title">Recently active near you.</h2>
            </div>
          </div>

          <div className="providers-grid">
            {PROVIDERS.slice(4).map((p) => (
              <ProviderCardGrid key={p.id} provider={p} onClick={onProvider}/>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "0 0 80px" }}>
        <div className="container">
          <div className="cta-banner">
            <div>
              <div className="eyebrow" style={{ color: "rgba(255,255,255,0.5)", marginBottom: 16 }}>◑ For service providers</div>
              <h2>Run your business, <em style={{ fontStyle: "italic", fontVariationSettings: "'SOFT' 100, 'WONK' 1" }}>not</em> your calendar.</h2>
            </div>
            <div>
              <p>Booking, payments, scheduling, reminders, and reviews — built into one tool. Keep 92% of every job. No monthly fees.</p>
              <div style={{ display: "flex", gap: 12, marginTop: 24 }}>
                <button className="btn btn-accent btn-lg" onClick={() => onNavigate("dashboard")}>List your service</button>
                <button className="btn btn-ghost btn-lg" style={{ color: "rgba(255,255,255,0.7)" }}>Watch tour</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer/>
    </main>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-col">
            <div className="brand" style={{ marginBottom: 16 }}>
              <span className="brand-mark"></span>
              <span>radius</span>
            </div>
            <p style={{ color: "var(--ink-3)", fontSize: 14, margin: 0, maxWidth: "32ch" }}>
              The honest way to find local services. Built in Brooklyn.
            </p>
          </div>
          <div className="footer-col">
            <h4>Services</h4>
            <ul>
              <li><a href="#">Home Cleaning</a></li>
              <li><a href="#">Handywork</a></li>
              <li><a href="#">Beauty & Wellness</a></li>
              <li><a href="#">Tutoring</a></li>
              <li><a href="#">All categories</a></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Company</h4>
            <ul>
              <li><a href="#">About</a></li>
              <li><a href="#">How it works</a></li>
              <li><a href="#">Trust & safety</a></li>
              <li><a href="#">Press</a></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Get started</h4>
            <ul>
              <li><a href="#">Find a pro</a></li>
              <li><a href="#">Become a provider</a></li>
              <li><a href="#">Sign in</a></li>
              <li><a href="#">Help center</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 Radius Inc. All rights reserved.</span>
          <span className="mono">v 2.0 · made with care</span>
        </div>
      </div>
    </footer>
  );
}

window.HomeScreen = HomeScreen;
window.Footer = Footer;
