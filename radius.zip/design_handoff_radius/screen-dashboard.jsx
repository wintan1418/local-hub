// Provider dashboard

function DashboardScreen({ onNavigate }) {
  const { BOOKINGS, MESSAGES } = window.RADIUS_DATA;
  const [section, setSection] = React.useState("overview");

  const navItems = [
    { id: "overview", label: "Overview", icon: "home" },
    { id: "bookings", label: "Bookings", icon: "calendar" },
    { id: "messages", label: "Messages", icon: "inbox", badge: 2 },
    { id: "earnings", label: "Earnings", icon: "dollar" },
    { id: "reviews", label: "Reviews", icon: "star" },
    { id: "profile", label: "Profile", icon: "user" },
    { id: "settings", label: "Settings", icon: "settings" },
  ];

  // Build a 7-point earnings sparkline path
  function spark(values, w = 100, h = 30) {
    const max = Math.max(...values);
    const min = Math.min(...values);
    const range = max - min || 1;
    return values.map((v, i) => {
      const x = (i / (values.length - 1)) * w;
      const y = h - ((v - min) / range) * (h - 4) - 2;
      return `${i === 0 ? "M" : "L"} ${x} ${y}`;
    }).join(" ");
  }

  const earnings = [320, 480, 412, 590, 510, 680, 740];
  const earningsBig = [1200, 1450, 1380, 1620, 1540, 1890, 2100, 1980, 2240, 2380, 2150, 2480];
  const months = ["May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr"];

  return (
    <div className="dashboard" data-screen-label="Provider Dashboard">
      <aside className="dash-side">
        <div className="dash-side-title">Maya Okonkwo</div>
        <nav className="dash-nav">
          {navItems.map(n => (
            <button key={n.id} className={`dash-link ${section === n.id ? "active" : ""}`} onClick={() => setSection(n.id)}>
              <Icon name={n.icon} size={16}/>
              <span>{n.label}</span>
              {n.badge && <span style={{ marginLeft: "auto", background: "var(--accent-2)", color: "white", fontSize: 11, padding: "1px 7px", borderRadius: 999, fontWeight: 600 }}>{n.badge}</span>}
            </button>
          ))}
        </nav>

        <div style={{ marginTop: 32, padding: 12, background: "var(--bg)", borderRadius: 8, fontSize: 12 }}>
          <div className="eyebrow" style={{ marginBottom: 8 }}>Profile health</div>
          <div style={{ height: 4, background: "var(--line)", borderRadius: 2, overflow: "hidden", marginBottom: 8 }}>
            <div style={{ width: "84%", height: "100%", background: "var(--accent)" }}></div>
          </div>
          <div style={{ color: "var(--ink-3)" }}>84% complete · <a href="#" style={{ color: "var(--accent)" }}>finish setup</a></div>
        </div>
      </aside>

      <main className="dash-main">
        <div className="dash-head">
          <div>
            <h1 className="dash-greeting">Good morning, Maya.</h1>
            <p className="dash-sub">You have 2 new requests and $740 in pending payouts this week.</p>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-secondary"><Icon name="calendar" size={14}/> Block time</button>
            <button className="btn btn-primary"><Icon name="plus" size={14}/> Add service</button>
          </div>
        </div>

        <div className="kpi-grid">
          <div className="kpi">
            <span className="kpi-label">This week</span>
            <span className="kpi-num">$740</span>
            <span className="kpi-trend">▲ 12% vs last week</span>
            <svg className="kpi-spark" viewBox="0 0 100 30" preserveAspectRatio="none">
              <path d={spark(earnings)} fill="none" stroke="var(--accent)" strokeWidth="1.5"/>
            </svg>
          </div>
          <div className="kpi">
            <span className="kpi-label">Bookings</span>
            <span className="kpi-num">17</span>
            <span className="kpi-trend">▲ 4 vs last week</span>
            <svg className="kpi-spark" viewBox="0 0 100 30" preserveAspectRatio="none">
              <path d={spark([3,5,4,6,5,8,7])} fill="none" stroke="var(--ink-2)" strokeWidth="1.5"/>
            </svg>
          </div>
          <div className="kpi">
            <span className="kpi-label">Rating</span>
            <span className="kpi-num">4.96</span>
            <span className="kpi-trend">▲ 0.02</span>
            <div style={{ marginTop: 6, fontSize: 12, color: "var(--ink-3)" }}>312 reviews · 92% are 5★</div>
          </div>
          <div className="kpi">
            <span className="kpi-label">Response time</span>
            <span className="kpi-num">12m</span>
            <span className="kpi-trend down">▼ 3m slower</span>
            <div style={{ marginTop: 6, fontSize: 12, color: "var(--ink-3)" }}>Goal: under 15 min</div>
          </div>
        </div>

        <div className="dash-grid-2">
          <div className="panel">
            <div className="panel-head">
              <h3 className="panel-title">Upcoming bookings</h3>
              <button className="btn btn-ghost btn-sm">View all <Icon name="arrow" size={12}/></button>
            </div>
            <div className="panel-body">
              {BOOKINGS.map(b => (
                <div className="booking-row" key={b.id}>
                  <div className="booking-date">
                    {b.date.includes("Tomorrow") ? (
                      <><span>29</span>APR</>
                    ) : (
                      <><span>{b.date.split(" ")[1]}</span>{b.date.split(" ")[0].toUpperCase()}</>
                    )}
                  </div>
                  <div className="booking-info">
                    <div className="booking-client">{b.client}</div>
                    <div className="booking-svc">{b.service} · {b.time}</div>
                  </div>
                  <span className={`status-pill ${b.status === "pending" ? "pending" : ""}`}>{b.status}</span>
                  <span className="booking-amount">${b.amount}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="panel">
            <div className="panel-head">
              <h3 className="panel-title">Messages</h3>
              <button className="btn btn-ghost btn-sm">Inbox <Icon name="arrow" size={12}/></button>
            </div>
            <div className="panel-body">
              {MESSAGES.map(m => (
                <div className="message-row" key={m.id}>
                  <Avatar name={m.from} size={36}/>
                  <div style={{ minWidth: 0 }}>
                    <div className="msg-from">
                      {m.unread && <span className="unread-dot"></span>}
                      {m.from}
                    </div>
                    <div className="msg-preview">{m.preview}</div>
                  </div>
                  <span className="msg-time">{m.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="panel">
          <div className="panel-head">
            <h3 className="panel-title">Earnings — last 12 months</h3>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span className="display" style={{ fontSize: 22 }}>$22,410</span>
              <span className="kpi-trend">▲ 28% YoY</span>
            </div>
          </div>
          <div className="chart-box">
            <svg className="chart-svg" viewBox="0 0 600 200" preserveAspectRatio="none">
              <defs>
                <linearGradient id="earnGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.2"/>
                  <stop offset="100%" stopColor="var(--accent)" stopOpacity="0"/>
                </linearGradient>
              </defs>
              {[0, 1, 2, 3].map(i => (
                <line key={i} x1="0" x2="600" y1={i * 50} y2={i * 50} stroke="var(--line)" strokeWidth="1"/>
              ))}
              {(() => {
                const max = Math.max(...earningsBig);
                const w = 600, h = 180;
                const pts = earningsBig.map((v, i) => [(i / (earningsBig.length - 1)) * w, h - (v / max) * h + 10]);
                const line = pts.map((p, i) => `${i ? "L" : "M"} ${p[0]} ${p[1]}`).join(" ");
                const area = `${line} L 600 200 L 0 200 Z`;
                return (
                  <>
                    <path d={area} fill="url(#earnGrad)"/>
                    <path d={line} fill="none" stroke="var(--accent)" strokeWidth="2"/>
                    {pts.map((p, i) => (
                      <circle key={i} cx={p[0]} cy={p[1]} r="3" fill="var(--bg-elevated)" stroke="var(--accent)" strokeWidth="1.5"/>
                    ))}
                  </>
                );
              })()}
            </svg>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--ink-3)", fontFamily: "var(--font-mono)", marginTop: 8 }}>
              {months.map(m => <span key={m}>{m}</span>)}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

window.DashboardScreen = DashboardScreen;
