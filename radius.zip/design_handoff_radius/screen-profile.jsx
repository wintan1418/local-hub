// Provider profile screen

function ProfileScreen({ providerId, onNavigate, onBook }) {
  const { PROVIDERS, REVIEWS } = window.RADIUS_DATA;
  const provider = PROVIDERS.find(p => p.id === providerId) || PROVIDERS[0];

  return (
    <main className="profile-page" data-screen-label="Provider Profile">
      <div className="container">
        <button className="btn btn-ghost btn-sm" style={{ marginTop: 20, paddingLeft: 0 }} onClick={() => onNavigate("search")}>
          <Icon name="arrowLeft" size={14}/> Back to results
        </button>

        <div className="profile-gallery">
          <ImgPlaceholder label={`${provider.name.toLowerCase().split(" ")[0]}-1.jpg · main`}/>
          <ImgPlaceholder label="work-1.jpg"/>
          <ImgPlaceholder label="work-2.jpg"/>
          <ImgPlaceholder label="work-3.jpg"/>
          <ImgPlaceholder label="work-4.jpg"/>
        </div>

        <div className="profile-layout">
          <div>
            <div className="profile-head">
              <div className="eyebrow profile-eyebrow">{provider.category}</div>
              <h1 className="profile-name">{provider.name}</h1>
              <p className="profile-title">{provider.title}</p>
              <div className="profile-stats">
                <span><Stars rating={provider.rating} count={provider.reviews}/></span>
                <span><Icon name="pin" size={14}/> {provider.location}</span>
                <span><Icon name="bolt" size={14}/> Responds in {provider.response}</span>
                <span><Icon name="check" size={14}/> {provider.completed} jobs completed</span>
              </div>
            </div>

            <div className="profile-section">
              <h3>About {provider.name.split(" ")[0]}</h3>
              <p className="profile-bio">
                {provider.bio || `Hi, I'm ${provider.name.split(" ")[0]}. I've been working in ${provider.category.toLowerCase()} for ${provider.yearsActive} years and I take pride in being someone you can actually count on. I bring my own tools, communicate clearly, and quote flat rates whenever I can. If we work together, expect a confirmation message within an hour and a genuine "thank you" when the job's done.`}
              </p>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 20 }}>
                {provider.badges.map(b => (
                  <span className="tag tag-accent" key={b}>
                    <Icon name="check" size={12}/> {b}
                  </span>
                ))}
              </div>
            </div>

            <div className="profile-section">
              <h3>What I offer</h3>
              <div className="skills-grid">
                {[
                  "Deep cleaning (move-in / move-out)",
                  "Standard recurring cleans",
                  "Airbnb turnover service",
                  "Eco-friendly supplies included",
                  "Pet-friendly (allergy aware)",
                  "Same-day availability",
                  "Flat-rate quotes by sq. ft.",
                  "Insured up to $1M",
                ].map(s => (
                  <div className="skill-row" key={s}>
                    <Icon name="check" size={16}/> {s}
                  </div>
                ))}
              </div>
            </div>

            <div className="profile-section">
              <h3>Reviews</h3>
              <div className="review-summary">
                <div>
                  <div className="review-big">{provider.rating.toFixed(2)}</div>
                  <Stars rating={provider.rating} showNum={false}/>
                  <div style={{ fontSize: 13, color: "var(--ink-3)", marginTop: 6 }}>{provider.reviews} reviews</div>
                </div>
                <div className="review-bars">
                  {[
                    { l: "5 stars", v: 92 },
                    { l: "4 stars", v: 6 },
                    { l: "3 stars", v: 1 },
                    { l: "2 stars", v: 0.5 },
                    { l: "1 star", v: 0.5 },
                  ].map(r => (
                    <div className="review-bar" key={r.l}>
                      <span style={{ width: 50 }}>{r.l}</span>
                      <span className="review-bar-track">
                        <span className="review-bar-fill" style={{ width: `${r.v}%` }}></span>
                      </span>
                      <span className="mono" style={{ width: 36, textAlign: "right" }}>{r.v}%</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="reviews-list">
                {REVIEWS.map(r => (
                  <div className="review-card" key={r.id}>
                    <div className="review-head">
                      <Avatar name={r.author} size={40}/>
                      <div>
                        <div className="review-author">{r.author}</div>
                        <div className="review-meta">
                          <Stars rating={r.rating} showNum={false}/>
                          <span>·</span>
                          <span>{r.date}</span>
                        </div>
                      </div>
                    </div>
                    <p className="review-body">{r.body}</p>
                    <span className="review-job">{r.job}</span>
                  </div>
                ))}
              </div>
              <button className="btn btn-secondary" style={{ marginTop: 16 }}>Show all {provider.reviews} reviews</button>
            </div>
          </div>

          <aside>
            <div className="booking-card">
              <div className="booking-rate">
                <div>
                  <span className="booking-rate-num">${provider.rate}</span>
                  <span className="muted" style={{ fontSize: 14 }}> / {provider.rateUnit}</span>
                </div>
                <Stars rating={provider.rating} count={provider.reviews} size={12}/>
              </div>

              <div className="booking-fields">
                <div className="booking-field">
                  <div>
                    <div className="booking-field-label">Date</div>
                    <div className="booking-field-val">Apr 30, 2026</div>
                  </div>
                  <div>
                    <div className="booking-field-label">Time</div>
                    <div className="booking-field-val">10:00 AM</div>
                  </div>
                </div>
                <div className="booking-field" style={{ gridTemplateColumns: "1fr" }}>
                  <div>
                    <div className="booking-field-label">Service</div>
                    <div className="booking-field-val">Deep clean · 1BR apt</div>
                  </div>
                </div>
              </div>

              <button className="btn btn-accent btn-lg booking-cta" onClick={onBook}>
                Request to book
              </button>
              <div style={{ textAlign: "center", fontSize: 12, color: "var(--ink-3)", marginTop: 10 }}>
                You won't be charged yet
              </div>

              <div className="booking-foot">
                <span>Estimated total</span>
                <span style={{ color: "var(--ink)", fontWeight: 600 }}>${provider.rate * 3}</span>
              </div>

              <button className="btn btn-secondary" style={{ width: "100%", marginTop: 12 }}>
                <Icon name="chat" size={14}/> Message {provider.name.split(" ")[0]}
              </button>
            </div>
          </aside>
        </div>
      </div>

      <Footer/>
    </main>
  );
}

window.ProfileScreen = ProfileScreen;
