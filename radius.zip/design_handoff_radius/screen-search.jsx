// Search results screen

function SearchScreen({ onProvider, onNavigate }) {
  const { PROVIDERS, CATEGORIES } = window.RADIUS_DATA;
  const [view, setView] = React.useState("list");
  const [activePin, setActivePin] = React.useState(null);
  const [selectedCats, setSelectedCats] = React.useState([]);

  const pinPositions = [
    { id: "maya", x: 28, y: 38 },
    { id: "diego", x: 52, y: 22 },
    { id: "harper", x: 68, y: 64 },
    { id: "ren", x: 38, y: 70 },
    { id: "asha", x: 78, y: 30 },
    { id: "marcus", x: 18, y: 60 },
    { id: "isla", x: 48, y: 50 },
    { id: "kai", x: 82, y: 52 },
  ];

  return (
    <div className="search-page" data-screen-label="Search Results">
      <aside className="search-filters">
        <div className="filter-group">
          <h4>Category</h4>
          <div className="filter-list">
            {CATEGORIES.map((c) => (
              <label key={c.id} className="filter-checkbox">
                <input
                  type="checkbox"
                  checked={selectedCats.includes(c.id)}
                  onChange={() => setSelectedCats(s =>
                    s.includes(c.id) ? s.filter(x => x !== c.id) : [...s, c.id]
                  )}
                />
                <span>{c.label}</span>
                <span className="filter-count">{c.count}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="filter-group">
          <h4>Price range</h4>
          <div className="range-input">
            <input className="input" placeholder="Min $"/>
            <input className="input" placeholder="Max $"/>
          </div>
        </div>

        <div className="filter-group">
          <h4>Rating</h4>
          <div className="filter-list">
            {[5, 4.5, 4, 3.5].map(r => (
              <label className="filter-checkbox" key={r}>
                <input type="checkbox"/>
                <span><Stars rating={r} showNum={false}/> & up</span>
              </label>
            ))}
          </div>
        </div>

        <div className="filter-group">
          <h4>Verification</h4>
          <div className="filter-list">
            {["Background checked", "Insured", "Licensed", "Top Rated"].map(v => (
              <label className="filter-checkbox" key={v}>
                <input type="checkbox"/>
                <span>{v}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="filter-group">
          <h4>Availability</h4>
          <div className="filter-list">
            {["Today", "Tomorrow", "This week", "Weekends"].map(v => (
              <label className="filter-checkbox" key={v}>
                <input type="checkbox"/>
                <span>{v}</span>
              </label>
            ))}
          </div>
        </div>

        <button className="btn btn-secondary btn-sm" style={{ width: "100%" }}>Clear filters</button>
      </aside>

      <section className="search-results">
        <div className="search-head">
          <div>
            <h2 className="search-count">{PROVIDERS.length} pros <span>near Brooklyn, NY</span></h2>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <select className="select" style={{ width: "auto", padding: "8px 32px 8px 12px", fontSize: 13 }}>
              <option>Sort: Recommended</option>
              <option>Highest rated</option>
              <option>Lowest price</option>
              <option>Distance</option>
              <option>Fastest response</option>
            </select>
            <div className="view-toggle">
              <button className={view === "list" ? "active" : ""} onClick={() => setView("list")}>
                <Icon name="list" size={16}/>
              </button>
              <button className={view === "grid" ? "active" : ""} onClick={() => setView("grid")}>
                <Icon name="grid" size={16}/>
              </button>
            </div>
          </div>
        </div>

        {view === "list" ? (
          <div className="search-list">
            {PROVIDERS.map(p => (
              <ProviderCardList key={p.id} provider={p} onClick={onProvider}/>
            ))}
          </div>
        ) : (
          <div className="search-grid">
            {PROVIDERS.map(p => (
              <ProviderCardGrid key={p.id} provider={p} onClick={onProvider}/>
            ))}
          </div>
        )}
      </section>

      <section className="search-map">
        <div className="map-canvas"></div>
        <div className="map-grid"></div>
        <svg className="map-roads" viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
          <path d="M 0,30 Q 30,40 50,35 T 100,40" fill="none" stroke="var(--line-strong)" strokeWidth="0.4"/>
          <path d="M 0,70 Q 40,65 60,72 T 100,68" fill="none" stroke="var(--line-strong)" strokeWidth="0.4"/>
          <path d="M 25,0 Q 30,40 28,80 T 30,100" fill="none" stroke="var(--line-strong)" strokeWidth="0.4"/>
          <path d="M 65,0 Q 70,40 68,80 T 70,100" fill="none" stroke="var(--line-strong)" strokeWidth="0.4"/>
        </svg>
        {pinPositions.map(p => {
          const provider = PROVIDERS.find(x => x.id === p.id);
          return (
            <button
              key={p.id}
              className={`map-pin ${activePin === p.id ? "active" : ""}`}
              style={{ left: `${p.x}%`, top: `${p.y}%` }}
              onClick={() => setActivePin(p.id)}
              onMouseEnter={() => setActivePin(p.id)}
            >
              ${provider.rate}
            </button>
          );
        })}
        <div style={{ position: "absolute", top: 16, left: 16, right: 16, display: "flex", gap: 8 }}>
          <button className="btn btn-secondary btn-sm" style={{ background: "var(--bg)" }}>
            <Icon name="pin" size={14}/> Search this area
          </button>
        </div>
      </section>
    </div>
  );
}

window.SearchScreen = SearchScreen;
