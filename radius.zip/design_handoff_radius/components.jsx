// Shared UI components for Radius

// ---------- Icon ----------
function Icon({ name, size = 16, stroke = 1.6 }) {
  const props = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  };
  const paths = {
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></>,
    pin: <><path d="M12 21s-7-6.5-7-12a7 7 0 0 1 14 0c0 5.5-7 12-7 12Z"/><circle cx="12" cy="9" r="2.5"/></>,
    star: <path d="M12 3.5l2.6 5.5 6 .85-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.85l6-.85L12 3.5z" fill="currentColor" stroke="none"/>,
    starOutline: <path d="M12 3.5l2.6 5.5 6 .85-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.85l6-.85L12 3.5z"/>,
    arrow: <><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></>,
    arrowLeft: <><path d="M19 12H5"/><path d="m11 18-6-6 6-6"/></>,
    check: <path d="m5 12 5 5 9-11"/>,
    chat: <path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-6.4A8 8 0 1 1 21 12Z"/>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></>,
    shield: <path d="M12 3 4 6v6c0 5 3.5 8.5 8 9 4.5-.5 8-4 8-9V6l-8-3Z"/>,
    bolt: <path d="M13 3 5 14h6l-1 7 8-11h-6l1-7z"/>,
    heart: <path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10Z"/>,
    sliders: <><path d="M4 6h12M20 6h0"/><path d="M4 18h6M14 18h6"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
    list: <><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r=".5" fill="currentColor"/><circle cx="3.5" cy="12" r=".5" fill="currentColor"/><circle cx="3.5" cy="18" r=".5" fill="currentColor"/></>,
    bell: <><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9Z"/><path d="M10 21a2 2 0 0 0 4 0"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    x: <><path d="M6 6l12 12M6 18 18 6"/></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    dollar: <><path d="M12 3v18"/><path d="M17 7c0-2-2-3-5-3s-5 1-5 3 2 3 5 3 5 1 5 3-2 3-5 3-5-1-5-3"/></>,
    home: <><path d="m3 11 9-7 9 7"/><path d="M5 10v10h14V10"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/></>,
    chart: <><path d="M3 3v18h18"/><path d="m7 15 4-5 3 3 5-7"/></>,
    inbox: <><path d="M3 13h5l1 3h6l1-3h5"/><path d="M3 13 6 5h12l3 8v6H3v-6Z"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></>,
  };
  return <svg {...props}>{paths[name] || null}</svg>;
}

// ---------- Avatar ----------
function Avatar({ name, size = 36, src }) {
  const initials = name ? name.split(" ").map(n => n[0]).slice(0, 2).join("") : "?";
  const hue = name ? (name.charCodeAt(0) * 17) % 360 : 0;
  return (
    <div
      className="avatar"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.36,
        background: `oklch(82% 0.04 ${hue})`,
        color: `oklch(28% 0.04 ${hue})`,
      }}
    >
      {initials}
    </div>
  );
}

// ---------- Image placeholder ----------
function ImgPlaceholder({ label, ratio = "16/9", style, rounded }) {
  return (
    <div className="img-ph" style={{ aspectRatio: ratio, borderRadius: rounded, ...style }}>
      <span className="img-ph-label">{label}</span>
    </div>
  );
}

// ---------- Stars ----------
function Stars({ rating, size = 13, showNum = true, count }) {
  return (
    <span className="stars" style={{ fontSize: size }}>
      <span style={{ color: "var(--ink)" }}><Icon name="star" size={size}/></span>
      <span style={{ fontWeight: 600 }}>{rating.toFixed(2)}</span>
      {showNum && count != null && <span style={{ color: "var(--ink-3)", fontWeight: 400 }}>({count})</span>}
    </span>
  );
}

// ---------- Top nav ----------
function TopNav({ current, onNavigate, onSearch }) {
  const links = [
    { id: "home", label: "Discover" },
    { id: "search", label: "Browse" },
    { id: "dashboard", label: "For Providers" },
  ];
  return (
    <nav className="topnav">
      <div className="topnav-inner">
        <a href="#" className="brand" onClick={(e) => { e.preventDefault(); onNavigate("home"); }}>
          <span className="brand-mark"></span>
          <span>radius</span>
        </a>
        <div className="nav-links hide-mobile">
          {links.map(l => (
            <button
              key={l.id}
              className={`nav-link ${current === l.id ? "active" : ""}`}
              onClick={() => onNavigate(l.id)}
            >
              {l.label}
            </button>
          ))}
        </div>
        <div className="nav-spacer"></div>
        <button className="btn btn-ghost btn-sm hide-mobile" onClick={() => onNavigate("dashboard")}>
          List your service
        </button>
        <button className="btn btn-secondary btn-sm">Sign in</button>
        <button className="btn btn-primary btn-sm hide-mobile">Join</button>
      </div>
    </nav>
  );
}

// ---------- Provider card (list view) ----------
function ProviderCardList({ provider, onClick }) {
  return (
    <button
      className="provider-card-list"
      onClick={() => onClick(provider.id)}
    >
      <ImgPlaceholder label={`${provider.name.toLowerCase().split(" ")[0]}.jpg`} ratio="1/1" style={{ width: 132, flexShrink: 0 }} />
      <div className="pcl-body">
        <div className="pcl-head">
          <div>
            <div className="eyebrow">{provider.category}</div>
            <h3 className="pcl-name">{provider.name}</h3>
            <div className="pcl-title">{provider.title}</div>
          </div>
          <button className="icon-btn" onClick={(e) => e.stopPropagation()}>
            <Icon name="heart" size={18}/>
          </button>
        </div>
        <div className="pcl-meta">
          <Stars rating={provider.rating} count={provider.reviews}/>
          <span className="dot"></span>
          <span><Icon name="pin" size={13}/> {provider.location}</span>
          <span className="dot"></span>
          <span className="muted">{provider.distance}</span>
        </div>
        <div className="pcl-foot">
          <div className="pcl-badges">
            {provider.badges.map(b => <span className="tag" key={b}>{b}</span>)}
          </div>
          <div className="pcl-rate">
            <span className="display" style={{ fontSize: 22 }}>${provider.rate}</span>
            <span className="muted" style={{ fontSize: 13 }}>/{provider.rateUnit}</span>
          </div>
        </div>
      </div>
    </button>
  );
}

// ---------- Provider card (grid view) ----------
function ProviderCardGrid({ provider, onClick }) {
  return (
    <div className="provider-card-grid" role="button" tabIndex={0} onClick={() => onClick(provider.id)} onKeyDown={(e) => { if (e.key === "Enter") onClick(provider.id); }}>
      <div className="pcg-img">
        <ImgPlaceholder label={`${provider.name.toLowerCase().split(" ")[0]}.jpg`} ratio="4/3" />
        {provider.badges.includes("Top Rated") && (
          <span className="pcg-badge">★ Top Rated</span>
        )}
        <span className="icon-btn pcg-fav" role="button" tabIndex={0} onClick={(e) => e.stopPropagation()}>
          <Icon name="heart" size={16}/>
        </span>
      </div>
      <div className="pcg-body">
        <div className="pcg-row">
          <h3 className="pcg-name">{provider.name}</h3>
          <Stars rating={provider.rating} count={provider.reviews} size={12}/>
        </div>
        <div className="pcg-title">{provider.title}</div>
        <div className="pcg-meta">
          <span><Icon name="pin" size={12}/> {provider.distance}</span>
          <span><Icon name="bolt" size={12}/> {provider.response}</span>
        </div>
        <div className="pcg-rate">
          <span className="display" style={{ fontSize: 20 }}>${provider.rate}</span>
          <span className="muted" style={{ fontSize: 13 }}>/{provider.rateUnit}</span>
        </div>
      </div>
    </div>
  );
}

// ---------- Icon button ----------
function IconButton({ icon, onClick, size = 36 }) {
  return (
    <button
      className="icon-btn"
      style={{ width: size, height: size }}
      onClick={onClick}
    >
      <Icon name={icon} size={size * 0.5}/>
    </button>
  );
}

Object.assign(window, {
  Icon, Avatar, ImgPlaceholder, Stars, TopNav,
  ProviderCardList, ProviderCardGrid, IconButton,
});
